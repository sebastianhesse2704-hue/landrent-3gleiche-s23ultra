plugins { id("com.android.application") }

android {
    namespace = "com.landrent.threeequal"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.landrent.threeequal"
        minSdk = 30
        targetSdk = 35
        versionCode = 203
        versionName = "2.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
