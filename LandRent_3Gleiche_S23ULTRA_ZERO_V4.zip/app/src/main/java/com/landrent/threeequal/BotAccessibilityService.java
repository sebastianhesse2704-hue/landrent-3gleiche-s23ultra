package com.landrent.threeequal;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.atomic.AtomicBoolean;

public class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;
    private final AtomicBoolean gestureBusy = new AtomicBoolean(false);
    private volatile long lastGestureAt = 0L;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    public boolean tap(float x, float y) {
        long now = SystemClock.uptimeMillis();
        if (now - lastGestureAt < 65L) return false;
        if (!gestureBusy.compareAndSet(false, true)) return false;

        float maxX = getResources().getDisplayMetrics().widthPixels - 2f;
        float maxY = getResources().getDisplayMetrics().heightPixels - 2f;
        float safeX = Math.max(2f, Math.min(maxX, x));
        float safeY = Math.max(2f, Math.min(maxY, y));
        Path path = new Path();
        path.moveTo(safeX, safeY);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0L, 30L))
                .build();
        lastGestureAt = now;
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) { gestureBusy.set(false); }
            @Override public void onCancelled(GestureDescription g) { gestureBusy.set(false); }
        }, null);
        if (!accepted) gestureBusy.set(false);
        return accepted;
    }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        gestureBusy.set(false);
        super.onDestroy();
    }
}
