package com.landrent.threeequal;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static volatile MainActivity instance;
    private TextView status;
    private Button botButton;
    private CaptureService service;
    private boolean bound = false, botEnabled = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int projectionRequest = 501;

    public static void updateBotStats(String s) {
        MainActivity a = instance;
        if (a != null) a.runOnUiThread(() -> {
            if (a.status != null && a.botEnabled) a.status.setText("BOT LÄUFT ✓\n" + s);
        });
    }

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            service = ((CaptureService.LocalBinder)b).service();
            bound = true;
            refresh();
        }
        @Override public void onServiceDisconnected(ComponentName n) {
            service = null;
            bound = false;
            refresh();
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        instance = this;
        buildUi();
        handler.post(poller);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable buttonBackground() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(235, 235, 235));
        d.setCornerRadius(dp(10));
        d.setStroke(dp(1), Color.rgb(190, 190, 190));
        return d;
    }

    private void styleButton(Button b) {
        b.setTextColor(Color.rgb(20, 20, 20));
        b.setTextSize(15f);
        b.setGravity(Gravity.CENTER);
        b.setAllCaps(false);
        b.setMinHeight(dp(52));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setBackground(buttonBackground());
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.WHITE);

        status = new TextView(this);
        status.setText("Touch AUS | Bildschirm AUS");
        status.setTextColor(Color.rgb(20, 20, 20));
        status.setTextSize(19f);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(8), 0, dp(18));
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));

        Button access = new Button(this);
        access.setText("1  Bedienungshilfe öffnen");
        styleButton(access);
        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access, buttonParams());

        Button capture = new Button(this);
        capture.setText("2  Bildschirmzugriff aktivieren");
        styleButton(capture);
        capture.setOnClickListener(v -> requestProjection());
        root.addView(capture, buttonParams());

        Button test = new Button(this);
        test.setText("Bildschirm testen");
        styleButton(test);
        test.setOnClickListener(v ->
                status.setText(CaptureService.running
                        ? "Bildschirmzugriff aktiv ✓"
                        : "Bildschirmzugriff AUS"));
        root.addView(test, buttonParams());

        botButton = new Button(this);
        botButton.setText("3  3-Gleiche-Bot starten");
        styleButton(botButton);
        botButton.setEnabled(false);
        botButton.setOnClickListener(v -> {
            if (service == null) return;
            botEnabled = !botEnabled;
            service.setBotEnabled(botEnabled);
            botButton.setText(botEnabled
                    ? "3-Gleiche-Bot stoppen"
                    : "3-Gleiche-Bot starten");
            status.setText(botEnabled
                    ? "BOT LÄUFT ✓\nLandRent jetzt öffnen"
                    : "BOT GESTOPPT");
        });
        root.addView(botButton, buttonParams());

        setContentView(root);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        p.bottomMargin = dp(12);
        return p;
    }

    private void requestProjection() {
        MediaProjectionManager m = getSystemService(MediaProjectionManager.class);
        startActivityForResult(m.createScreenCaptureIntent(), projectionRequest);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != projectionRequest) return;
        if (result != RESULT_OK || data == null) {
            status.setText("Bildschirmfreigabe abgebrochen");
            return;
        }
        Intent i = new Intent(this, CaptureService.class);
        i.putExtra(CaptureService.EXTRA_RESULT_CODE, result);
        i.putExtra(CaptureService.EXTRA_DATA, data);
        startForegroundService(i);
        bindService(new Intent(this, CaptureService.class), connection, BIND_AUTO_CREATE);
        status.setText("Bildschirmzugriff startet…");
    }

    private void refresh() {
        boolean touch = BotAccessibilityService.instance != null;
        boolean cap = CaptureService.running;
        if (botButton != null) botButton.setEnabled(touch && cap && bound);
        if (!botEnabled && status != null) {
            status.setText(!touch && !cap
                    ? "Touch AUS | Bildschirm AUS"
                    : !touch
                    ? "Bildschirm ✓ | Bedienungshilfe fehlt"
                    : !cap
                    ? "Touch ✓ | Bildschirm AUS"
                    : "Touch ✓ | Bildschirm ✓");
        }
    }

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 500);
        }
    };

    @Override protected void onDestroy() {
        if (bound) {
            try { unbindService(connection); } catch (Exception ignored) {}
            bound = false;
        }
        handler.removeCallbacks(poller);
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
