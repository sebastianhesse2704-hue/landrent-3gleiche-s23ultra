package com.landrent.threeequal;

import android.graphics.Bitmap;
import android.os.SystemClock;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Pure Android vision solver. It does not contain a fruit list.
 *
 * Strategy:
 * 1. Find cream-colored tile faces by connected components.
 * 2. Keep physical tile candidates and suppress covered/duplicate candidates.
 * 3. Build a color/shape descriptor from the fruit pixels.
 * 4. Cluster visually identical tiles.
 * 5. Prefer completing a pair already in the 7-slot tray, then triples/pairs.
 * 6. After every successful tap, wait for a new frame and re-evaluate the whole board.
 */
public final class BotEngine {
    public interface Tapper { boolean tap(float x, float y); }
    public interface Listener { void onStats(String text); }

    private final Tapper tapper;
    private final Listener listener;
    private volatile boolean enabled;
    private long lastAction = 0L;

    private static final class Tile {
        final float cx, cy, w, h;
        final float[] desc;
        final int area;
        Tile(float cx, float cy, float w, float h, float[] desc, int area) {
            this.cx=cx; this.cy=cy; this.w=w; this.h=h; this.desc=desc; this.area=area;
        }
    }
    private static final class Group { final List<Tile> tiles = new ArrayList<>(); }
    private static final class Candidate {
        final float cx, cy, w, h; final int area;
        Candidate(float cx,float cy,float w,float h,int area){this.cx=cx;this.cy=cy;this.w=w;this.h=h;this.area=area;}
    }

    public BotEngine(Tapper tapper, Listener listener) { this.tapper=tapper; this.listener=listener; }
    public void setEnabled(boolean value) { enabled=value; }
    public boolean isEnabled() { return enabled; }

    public void process(Bitmap frame, float scaleX, float scaleY) {
        if (!enabled || frame == null) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastAction < 65L) return;
        if (frame.getWidth() < 300 || frame.getHeight() < 500) return;

        List<Tile> boardAll = detectTiles(frame, 0.31f, 0.82f);
        if (boardAll.size() < 2) { stats("Erkannt: " + boardAll.size()); return; }
        List<Tile> board = exposed(boardAll);
        List<Tile> tray = detectTiles(frame, 0.09f, 0.23f);
        List<Group> groups = cluster(board);

        // A group is considered useful if it has a tray mate or at least a pair on board.
        Group finish = null;
        int finishTray = 0;
        for (Group g : groups) {
            if (g.tiles.isEmpty()) continue;
            int tc = similarCount(g.tiles.get(0), tray);
            if (tc >= 2 && (finish == null || tc*100+g.tiles.size() > finishTray*100+finish.tiles.size())) {
                finish=g; finishTray=tc;
            }
        }
        if (finish != null) { clickOne(finish.tiles.get(0), scaleX, scaleY); return; }

        Group triple = bestGroup(groups, 3, tray);
        if (triple != null) {
            // One tap per fresh frame. This is deliberate: the board changes after every tap.
            clickOne(triple.tiles.get(0), scaleX, scaleY); return;
        }

        Group pair = bestGroup(groups, 2, tray);
        if (pair != null) {
            int tc=similarCount(pair.tiles.get(0),tray);
            // If there is already one in the tray, taking two would complete it.
            // Otherwise take one to avoid flooding the tray.
            clickOne(pair.tiles.get(0), scaleX, scaleY); return;
        }

        // No visible pair: only take a single tile if its class has a tray mate.
        Group trayMate=null; int best=-1;
        for (Group g:groups) {
            if(g.tiles.isEmpty()) continue;
            int tc=similarCount(g.tiles.get(0),tray);
            if(tc>0 && tc>best){best=tc;trayMate=g;}
        }
        if(trayMate!=null) { clickOne(trayMate.tiles.get(0),scaleX,scaleY); return; }

        stats("Erkannt: " + board.size() + " frei | keine sichere Aktion");
    }

    private void clickOne(Tile t, float sx, float sy) {
        float x=t.cx*sx, y=t.cy*sy;
        if(tapper.tap(x,y)) {
            lastAction=SystemClock.uptimeMillis();
            stats("Tap: " + Math.round(x) + "," + Math.round(y));
        }
    }

    private void stats(String s) { if(listener!=null) listener.onStats(s); }

    private static Group bestGroup(List<Group> groups,int minSize,List<Tile> tray){
        Group best=null; int bestScore=-1;
        for(Group g:groups){
            if(g.tiles.size()<minSize) continue;
            int tc=similarCount(g.tiles.get(0),tray);
            int score=tc*100+g.tiles.size();
            if(best==null||score>bestScore){best=g;bestScore=score;}
        }
        return best;
    }

    private static int similarCount(Tile t,List<Tile> list){
        int n=0; for(Tile x:list) if(distance(t.desc,x.desc)<0.115f) n++; return n;
    }

    private static List<Group> cluster(List<Tile> tiles){
        List<Group> out=new ArrayList<>();
        for(Tile t:tiles){
            Group hit=null;
            for(Group g:out) if(distance(t.desc,g.tiles.get(0).desc)<0.115f){hit=g;break;}
            if(hit==null){hit=new Group();out.add(hit);} hit.tiles.add(t);
        }
        return out;
    }

    private static List<Tile> exposed(List<Tile> all){
        List<Tile> out=new ArrayList<>();
        // The game stacks cards in vertical layers.  The old rule compared the
        // center distance against only ~20% of the card height, which made a
        // lower, covered card look free.  Use the actual card rectangles with a
        // small shadow/edge tolerance and only let a card above another card
        // block it.  This is deliberately conservative: when in doubt we do
        // not click the lower card.
        final float edge=12f;
        for(Tile t:all){
            boolean covered=false;
            float tLeft=t.cx-t.w/2f-edge, tRight=t.cx+t.w/2f+edge;
            float tTop=t.cy-t.h/2f-edge, tBottom=t.cy+t.h/2f+edge;
            for(Tile o:all){
                if(o==t || o.cy>=t.cy) continue; // only a card above can cover t
                float oLeft=o.cx-o.w/2f-edge, oRight=o.cx+o.w/2f+edge;
                float oTop=o.cy-o.h/2f-edge, oBottom=o.cy+o.h/2f+edge;
                float ix=Math.min(tRight,oRight)-Math.max(tLeft,oLeft);
                float iy=Math.min(tBottom,oBottom)-Math.max(tTop,oTop);
                float minWidth=Math.min(t.w,o.w)*0.16f;
                if(ix>minWidth && iy>0f){ covered=true; break; }
            }
            if(!covered) out.add(t);
        }
        // Front-most first.  If several identical cards are free, the one that
        // is visually highest is safest and tends to expose the next layer.
        Collections.sort(out, Comparator.comparingDouble(a -> a.cy));
        return out;
    }

    private static List<Tile> detectTiles(Bitmap src,float topFrac,float bottomFrac){
        int w=src.getWidth(), h=src.getHeight();
        int y0=Math.max(0,(int)(h*topFrac)), y1=Math.min(h,(int)(h*bottomFrac));
        int step=Math.max(1,w/720); // 1 px at 720p, 2 px on S23 Ultra full capture.
        int sw=(w+step-1)/step, sh=Math.max(1,(y1-y0+step-1)/step);
        boolean[] mask=new boolean[sw*sh];
        for(int yy=0;yy<sh;yy++){
            int sy=Math.min(h-1,y0+yy*step+step/2);
            for(int xx=0;xx<sw;xx++){
                int sx=Math.min(w-1,xx*step+step/2);
                int c=src.getPixel(sx,sy);
                int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
                int mx=Math.max(r,Math.max(g,b)), mn=Math.min(r,Math.min(g,b));
                // Tile faces are warm/cream: bright, with R >= G >= B.
                mask[yy*sw+xx]=mx>=170 && r>=g-10 && g>=b-18 && (r-g)>=2;
            }
        }
        boolean[] seen=new boolean[mask.length];
        int[] q=new int[mask.length];
        List<Candidate> cs=new ArrayList<>();
        int minW=Math.max(8,(int)(w*0.075f/step));
        int maxW=Math.min(sw,(int)(w*0.17f/step));
        int minH=Math.max(8,(int)(h*0.040f/step));
        int maxH=Math.min(sh,(int)(h*0.095f/step));
        int minArea=Math.max(25,(int)((w*0.11f/step)*(h*0.045f/step)*0.18f));

        for(int start=0;start<mask.length;start++){
            if(!mask[start]||seen[start]) continue;
            int head=0,tail=0; q[tail++]=start;seen[start]=true;
            int minX=start%sw,maxX=minX,minY=start/sw,maxY=minY,area=0;
            while(head<tail){
                int p=q[head++],x=p%sw,y=p/sw; area++;
                if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y;
                if(x>0&&mask[p-1]&&!seen[p-1]){seen[p-1]=true;q[tail++]=p-1;}
                if(x+1<sw&&mask[p+1]&&!seen[p+1]){seen[p+1]=true;q[tail++]=p+1;}
                if(y>0&&mask[p-sw]&&!seen[p-sw]){seen[p-sw]=true;q[tail++]=p-sw;}
                if(y+1<sh&&mask[p+sw]&&!seen[p+sw]){seen[p+sw]=true;q[tail++]=p+sw;}
            }
            int bw=maxX-minX+1,bh=maxY-minY+1;
            if(area>=minArea&&bw>=minW&&bw<=maxW&&bh>=minH&&bh<=maxH){
                float cx=(minX+maxX+1)*step/2f;
                float cy=y0+(minY+maxY+1)*step/2f;
                cs.add(new Candidate(cx,cy,bw*step,bh*step,area));
            }
        }
        Collections.sort(cs, (a,b)->Integer.compare(b.area,a.area));
        List<Tile> out=new ArrayList<>();
        for(Candidate c:cs){
            boolean duplicate=false;
            for(Tile t:out){
                if(Math.abs(t.cx-c.cx)<w*0.065f && Math.abs(t.cy-c.cy)<h*0.038f){duplicate=true;break;}
            }
            if(duplicate) continue;
            int hw=Math.max(14,(int)(c.w*0.45f)), hh=Math.max(14,(int)(c.h*0.45f));
            out.add(new Tile(c.cx,c.cy,c.w,c.h,descriptor(src,Math.round(c.cx),Math.round(c.cy),hw,hh),c.area));
        }
        return out;
    }

    private static float[] descriptor(Bitmap src,int cx,int cy,int hw,int hh){
        // Hue histogram of colorful pixels. The game artwork keeps the same visual
        // class even when the card is at another position. No fruit names are used.
        float[] out=new float[18];
        int left=Math.max(0,cx-hw), top=Math.max(0,cy-hh);
        int right=Math.min(src.getWidth()-1,cx+hw), bottom=Math.min(src.getHeight()-1,cy+hh);
        float[] hsv=new float[3];
        for(int y=top;y<=bottom;y++){
            for(int x=left;x<=right;x++){
                int c=src.getPixel(x,y);
                int r=(c>>16)&255, g=(c>>8)&255, b=c&255;
                android.graphics.Color.RGBToHSV(r,g,b,hsv);
                if(hsv[1] < 0.275f || hsv[2] < 0.20f || hsv[2] > 0.98f) continue;
                int bin=Math.min(17,(int)(hsv[0]/20f));
                out[bin]+=1f;
            }
        }
        float norm=0f;
        for(float v:out) norm+=v*v;
        norm=(float)Math.sqrt(norm)+1e-6f;
        for(int i=0;i<out.length;i++) out[i]/=norm;
        return out;
    }

    private static float distance(float[] a,float[] b){float s=0;for(int i=0;i<a.length;i++){float d=a[i]-b[i];s+=d*d;}return (float)Math.sqrt(s);}
}
