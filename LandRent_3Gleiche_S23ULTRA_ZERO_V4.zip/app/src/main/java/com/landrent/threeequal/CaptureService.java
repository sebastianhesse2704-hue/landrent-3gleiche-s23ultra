package com.landrent.threeequal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.widget.Toast;

public class CaptureService extends Service {
    public static final String EXTRA_RESULT_CODE="projection_result_code";
    public static final String EXTRA_DATA="projection_data";
    public static volatile boolean running=false;

    private final IBinder binder=new LocalBinder();
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private boolean botEnabled=false;
    private long lastFrame=0L;
    private int screenW=1,screenH=1;
    private BotEngine bot;

    public class LocalBinder extends android.os.Binder { public CaptureService service(){return CaptureService.this;} }

    @Override public void onCreate(){
        super.onCreate();
        createChannel();
        startAsForeground();
        bot=new BotEngine((x,y)->BotAccessibilityService.instance!=null && BotAccessibilityService.instance.tap(x,y),
                text->MainActivity.updateBotStats(text));
    }

    @Override public IBinder onBind(Intent intent){return binder;}

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null){
            int rc=intent.getIntExtra(EXTRA_RESULT_CODE,Integer.MIN_VALUE);
            Intent data;
            if(Build.VERSION.SDK_INT>=33) data=intent.getParcelableExtra(EXTRA_DATA,Intent.class);
            else { //noinspection deprecation
                data=intent.getParcelableExtra(EXTRA_DATA);
            }
            if(rc!=Integer.MIN_VALUE && data!=null && !running) startProjection(rc,data);
        }
        return START_NOT_STICKY;
    }

    public void setBotEnabled(boolean value){
        botEnabled=value && running && BotAccessibilityService.instance!=null;
        if(bot!=null)bot.setEnabled(botEnabled);
        Toast.makeText(this,botEnabled?"Bot läuft":"Bot gestoppt",Toast.LENGTH_SHORT).show();
    }
    public boolean isBotEnabled(){return botEnabled;}

    private void startProjection(int resultCode,Intent data){
        try{
            MediaProjectionManager mpm=getSystemService(MediaProjectionManager.class);
            projection=mpm.getMediaProjection(resultCode,data);
            if(projection==null)throw new IllegalStateException("MediaProjection null");
            projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopCapture();}},null);
            DisplayMetrics dm=new DisplayMetrics();
            //noinspection deprecation
            ((android.view.WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            screenW=dm.widthPixels;screenH=dm.heightPixels;
            reader=ImageReader.newInstance(screenW,screenH,PixelFormat.RGBA_8888,2);
            reader.setOnImageAvailableListener(ir->onImage(ir),null);
            display=projection.createVirtualDisplay("LandRent3Gleiche",screenW,screenH,dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
            running=true;
            Toast.makeText(this,"Bildschirmzugriff aktiv ✓",Toast.LENGTH_SHORT).show();
        }catch(Throwable t){
            Toast.makeText(this,"Bildschirmzugriff fehlgeschlagen: "+t.getClass().getSimpleName(),Toast.LENGTH_LONG).show();
            stopCapture();
        }
    }

    private void onImage(ImageReader ir){
        long now=SystemClock.uptimeMillis();
        if(now-lastFrame<60L){Image old=ir.acquireLatestImage();if(old!=null)old.close();return;}
        lastFrame=now;
        Image image=ir.acquireLatestImage();if(image==null)return;
        Bitmap raw=null,small=null;
        try{
            Image.Plane plane=image.getPlanes()[0];
            int pixelStride=plane.getPixelStride(), rowStride=plane.getRowStride();
            int rowPadding=rowStride-pixelStride*screenW;
            int bw=screenW+rowPadding/pixelStride;
            raw=Bitmap.createBitmap(bw,screenH,Bitmap.Config.ARGB_8888);
            raw.copyPixelsFromBuffer(plane.getBuffer());
            Bitmap exact=(bw==screenW)?raw:Bitmap.createBitmap(raw,0,0,screenW,screenH);
            int targetW=Math.min(720,screenW);
            int targetH=Math.max(1,Math.round(screenH*(targetW/(float)screenW)));
            small=Bitmap.createScaledBitmap(exact,targetW,targetH,true);
            if(exact!=raw)exact.recycle();
            if(botEnabled)bot.process(small,screenW/(float)targetW,screenH/(float)targetH);
        }catch(Throwable ignored){
        }finally{
            if(small!=null)small.recycle();
            if(raw!=null)raw.recycle();
            image.close();
        }
    }

    private void stopCapture(){
        running=false;botEnabled=false;if(bot!=null)bot.setEnabled(false);
        if(display!=null){display.release();display=null;}
        if(reader!=null){reader.close();reader=null;}
        if(projection!=null){try{projection.stop();}catch(Exception ignored){}projection=null;}
    }

    @Override public void onDestroy(){stopCapture();super.onDestroy();}

    private void startAsForeground(){
        Notification n=new Notification.Builder(this,"landrent_capture")
                .setContentTitle("LandRent 3 Gleiche")
                .setContentText("Bildschirmzugriff aktiv")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(1001,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1001,n);
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel("landrent_capture","LandRent Bot",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
}
