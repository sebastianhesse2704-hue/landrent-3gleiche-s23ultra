# LandRent 3 Gleiche – S23 Ultra

Version 2.3 Fast. Visuelle Erkennung ohne fest codierte Fruchtnamen. Nach jedem Klick wird der Bildschirm neu bewertet; überdeckte Karten werden konservativ ausgeschlossen. Die Bildanalyse läuft mit kürzerem Frame- und Aktionsintervall, und Touch-Gesten sind kürzer.
