package com.landrent.threeequal;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static volatile MainActivity instance;
    private TextView status;
    private Button botButton;
    private CaptureService service;
    private boolean bound=false, botEnabled=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final int projectionRequest=501;

    public static void updateBotStats(String s){
        MainActivity a=instance;
        if(a!=null)a.runOnUiThread(()->{if(a.status!=null && a.botEnabled)a.status.setText("BOT LÄUFT ✓\n"+s);});
    }

    private final ServiceConnection connection=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName n,IBinder b){service=((CaptureService.LocalBinder)b).service();bound=true;refresh();}
        @Override public void onServiceDisconnected(ComponentName n){service=null;bound=false;refresh();}
    };

    @Override protected void onCreate(Bundle b){super.onCreate(b);instance=this;buildUi();handler.post(poller);}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(34,34,34,34);
        status=new TextView(this);status.setText("1. Bedienungshilfe\n2. Bildschirmzugriff\n3. Bot starten");status.setTextSize(18f);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,120));
        Button access=new Button(this);access.setText("1  BEDIENUNGSHILFE ÖFFNEN");access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(access,p());
        Button capture=new Button(this);capture.setText("2  BILDSCHIRMZUGRIFF AKTIVIEREN");capture.setOnClickListener(v->requestProjection());root.addView(capture,p());
        Button test=new Button(this);test.setText("BILDSCHIRM TESTEN");test.setOnClickListener(v->status.setText(CaptureService.running?"Bildschirmzugriff aktiv ✓":"Bildschirmzugriff AUS"));root.addView(test,p());
        botButton=new Button(this);botButton.setText("3  3-GLEICHE-BOT STARTEN");botButton.setEnabled(false);botButton.setOnClickListener(v->{
            if(service==null)return;botEnabled=!botEnabled;service.setBotEnabled(botEnabled);botButton.setText(botEnabled?"3-GLEICHE-BOT STOPPEN":"3-GLEICHE-BOT STARTEN");
            status.setText(botEnabled?"BOT LÄUFT ✓\nLandRent jetzt öffnen":"BOT GESTOPPT");
        });root.addView(botButton,p());
        setContentView(root);
    }
    private LinearLayout.LayoutParams p(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,70);p.bottomMargin=16;return p;}

    private void requestProjection(){MediaProjectionManager m=getSystemService(MediaProjectionManager.class);startActivityForResult(m.createScreenCaptureIntent(),projectionRequest);}

    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=projectionRequest)return;if(result!=RESULT_OK||data==null){status.setText("Bildschirmfreigabe abgebrochen");return;}
        Intent i=new Intent(this,CaptureService.class);i.putExtra(CaptureService.EXTRA_RESULT_CODE,result);i.putExtra(CaptureService.EXTRA_DATA,data);startForegroundService(i);bindService(new Intent(this,CaptureService.class),connection,BIND_AUTO_CREATE);status.setText("Bildschirmzugriff startet…");}

    private void refresh(){boolean touch=BotAccessibilityService.instance!=null;boolean cap=CaptureService.running;botButton.setEnabled(touch&&cap&&bound);if(!botEnabled)status.setText(!touch&&!cap?"Touch AUS | Bildschirm AUS":!touch?"Bildschirm ✓ | Bedienungshilfe fehlt":!cap?"Touch ✓ | Bildschirm AUS":"Touch ✓ | Bildschirm ✓");}

    private final Runnable poller=new Runnable(){@Override public void run(){refresh();handler.postDelayed(this,500);}};
    @Override protected void onDestroy(){if(bound){try{unbindService(connection);}catch(Exception ignored){}bound=false;}handler.removeCallbacks(poller);if(instance==this)instance=null;super.onDestroy();}
}
