# LandRent 3 Gleiche – S23 Ultra, Clean Start

Dieses Projekt ist bewusst ohne Kotlin und ohne externe Vision-Bibliothek aufgebaut. Dadurch gibt es keine Kotlin/Java-JVM-Target-Mischung und keine OpenCV-Abhängigkeit.

Der Solver enthält keine Fruchtliste. Er erkennt die hellen Karten visuell, gruppiert identische Motive über einen visuellen Deskriptor und tippt pro neuem Bildschirmbild höchstens einmal. Nach jedem Tap wird der komplette Bildschirm erneut ausgewertet.

## S23 Ultra
- Android 15/16-kompatible MediaProjection-Architektur
- AccessibilityService für echte Gesten
- Verarbeitung auf 720 px Breite, Koordinaten werden auf die echte Bildschirmauflösung zurückskaliert
- 120-ms Frame-Drosselung und 170-ms Sicherheitsabstand nach einem Tap
- kein separater Auto-Clicker erforderlich

## Ablauf
1. Bedienungshilfe einschalten
2. Bildschirmzugriff erlauben
3. Bot starten
4. LandRent öffnen und das 3-Gleiche-Spiel starten

Der Bot klickt nur nach visueller Erkennung und stoppt bei unsicherer Lage statt blind zu tippen.


## S23 Ultra V2.1
UI uses density-independent dimensions and explicit dark text so controls remain readable on Samsung One UI. Version code 201.
